﻿using Microsoft.AspNetCore.Identity;

namespace Unicorn.Entities
{
    public class User : IdentityUser
    {
    }
}
