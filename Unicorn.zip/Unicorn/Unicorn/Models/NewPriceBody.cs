﻿namespace Unicorn.Models
{
    public class NewPriceBody
    {
        public float NewPrice { get; set; }
    }
}
