﻿namespace Unicorn.Models
{
    public class CarWeb
    {
        public int CarId { get; set; }
        public string CarName { get; set; }
    }
}
