﻿namespace Unicorn.Models
{
    public class Error
    {
        public string Message { get; set; }
        public string Code { get; set; }
    }
}
