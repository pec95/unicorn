﻿namespace Unicorn.Models
{
    public class CarParts
    {
        public string BrandCar { get; set; }
        public int PartsNumber { get; set; }
    }
}
