export class ArticlePost { 
    serialNumber: number;
    price: number;

    constructor(serialNumber: number, price: number) {
        this.serialNumber = serialNumber;
        this.price = price;
    } 
}