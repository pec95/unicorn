export class Car {
    carId: number;
    carName: string;

    constructor(carId: number, carName: string) {
        this.carId = carId;
        this.carName = carName; 
    } 
}